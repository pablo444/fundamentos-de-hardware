/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ecercicio78;

import java.util.Scanner;

public class Ecercicio78 {
    static int[] trabajadores = new int [10];
    static Scanner leer =new Scanner(System.in);
    public static void main(String[] args) {
       int opcion = 0;
         do{
         
        System.out.println("nenu \n 1) ingrese las horas trabajasa de los 10 trabajadors "
                + "\n 2)carcular pago de horas extras \n 3)calcular los salarios \n 4)salir.......");
           opcion= leer.nextInt();
      if(opcion==1){
       ingresaHoras();
      }
      else if(opcion==2){
       calcularHorasExtras();
      }
      else if(opcion==3){
       calcularSalarios();
      }}while(opcion !=4);}
    public static void ingresaHoras(){
        System.out.println("Ingrese las horas  trabajadas");
        for (int i = 0; i < 10; i++) {   
            System.out.print("horas del trabajador [n°"+(i+1)+"] :");
        trabajadores[i] = leer.nextInt();
            }
        }
    public static void calcularSalarios(){
      for(int i = 0; i < 10; i++){
       if(40>trabajadores[i]){
          trabajadores[i]=trabajadores[i]*5000 ;
       }
       else if(trabajadores[i] >= 40 && trabajadores[i] <= 43){
         int aux=trabajadores[i]-40;
        trabajadores[i] =(aux*2000)+(40*5000) ;         
       }
       else if(trabajadores[i] >= 40 && trabajadores[i] <= 47){
        int aux=trabajadores[i]-40;
       int aux2= aux-3;
       trabajadores[i] =(40*5000)+(aux2*3000)+((aux-aux2)*2000); 
       }
       else if(trabajadores[i] > 47 ){
        int aux=trabajadores[i]-40;
       int aux3 =aux - 7  ;
       trabajadores[i] =(40*5000)+(4*3000)+(3*2000)+(aux3 *3500);       }   
       
        System.out.println("el salaroit  trabajador n°"+(i+1)+" gano :"+trabajadores[i]);}
      }
       public static void calcularHorasExtras(){
      for(int i = 0; i < 10; i++){
       if(40>trabajadores[i]){
          trabajadores[i]=trabajadores[i]*5000 ;
       }
       else if(trabajadores[i] >= 40 && trabajadores[i] <= 43){
         int aux=trabajadores[i]-40;
        trabajadores[i] =(aux*2000) ;         
       }
       else if(trabajadores[i] > 43 && trabajadores[i] <= 47){
        int aux=trabajadores[i]-40;
       int aux2= aux-3;
       trabajadores[i] =(aux2*3000)+(3*2000); 
       }
       else if(trabajadores[i] > 47 ){
        int aux=trabajadores[i]-40;
       int aux3 =aux - 7  ;
       trabajadores[i] =(4*3000)+(3*2000)+(aux3 *3500);       }   
       
        System.out.println("se le paga al trabajador  ]n°"+(i+1)+"] por sus horas extra :"+trabajadores[i]);}
      }
// TODO code application logic here
    }
    

