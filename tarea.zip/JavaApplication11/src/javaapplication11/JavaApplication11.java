/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

import java.util.Scanner;
import java.text.DecimalFormat;

public class JavaApplication11 {

    public static void main(String[] args) {
        double kilometros_ciudad1;
        double kilometros_ciudad2;
        double kilometros_ciudad3;
        double kilometros = 0;
        double precio;
        int numciudad;
        int kilogramos;
        int i = 0;
        int rep;
        int camionG=0;
        int camionP=0;
        double precio_final = 0;
        Scanner p = new Scanner(System.in);
       DecimalFormat valor = new DecimalFormat("#.000");
        do {
            System.out.println("ingrese kilometros recorridos para la ciudad 1 ");
            kilometros_ciudad1= p.nextDouble();
            if (kilometros_ciudad1 < 0) {
                System.out.println("los kilomeros son invalidos ingrese otra vez");
            }
        } while (kilometros_ciudad1 < 0);
          do {
            System.out.println("ingrese kilometros recorridos para la ciudad 2 ");
            kilometros_ciudad2= p.nextDouble();
            if (kilometros_ciudad2 < 0) {
                System.out.println("los kilomeros son invalidos ingrese otra vez");
            }
        } while (kilometros_ciudad2 < 0);
            do {
            System.out.println("ingrese kilometros recorridos para la ciudad 3 ");
            kilometros_ciudad3= p.nextDouble();
            if (kilometros_ciudad3 < 0) {
                System.out.println("los kilomeros son invalidos ingrese otra vez");
            }
        } while (kilometros_ciudad3 < 0);
       do{
          do {
            System.out.println("ingrese el precio de la gasolina");
            precio = p.nextDouble();
            if (precio < 0) {
                System.out.println("el precio es invalido ingrese otra vez");
            }
        } while (precio < 0);
         System.out.println("elija la ciudad 1 , 2 o 3 para el embio");
          numciudad = p.nextInt();
          if(numciudad ==1){
          kilometros = kilometros_ciudad1; }
          if(numciudad ==2){
          kilometros = kilometros_ciudad2; }
          if(numciudad ==3){
          kilometros = kilometros_ciudad3; }
            do {
            System.out.println("peso en kilos del embio");
            kilogramos = p.nextInt();
            if (kilogramos < 0) {
                System.out.println("los kilogramos son invalidos ingrese otra vez");
            }
        } while (kilogramos < 0);
        double Dividir = precio / 23;
        double multiplicar = Dividir * kilometros;
         precio_final = precio_final + multiplicar ;

        System.out.println(" gasto gasto en el embio: ( " +valor.format(multiplicar)+ "  pesos)  al recorre  " +kilometros+ "  kilometros");
        if (kilogramos <= 100 && kilogramos >= 0) {
            System.out.println(" en un camion pequeño");
        ++camionP;
        } else if (kilogramos >= 101 && kilogramos <= 200) {
            System.out.println("en un camion grande");
             ++camionG;
        }
           System.out.println("¿Desea volber a hacer un enbio? aprete cualquier numero)si   0)no ");
           rep= p.nextInt();
           ++i;
          if(rep==0){
              System.out.println("gracias por su enbio su voleta es");
          }
       }while( rep !=0 );
        System.out.println("se hisieron "+i+" enbios");
        System.out.println("se usaron "+camionG+" Camiones grandes y "+camionP+" Camiones pequeños"); 
        System.out.println("el valor final de sus embios es ("+valor.format(precio_final)+" pesos)");
    }
}

// TODO code application logic here

