/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loto;

import java.util.Random;
import java.util.Scanner;

public class Loto {

    public static void main(String[] args) {
        int punt1 = 0;
        int punt2 = 0;
        int punt3 = 0;
        int punt4 = 0;
        int punt5 = 0;
        int punt6 = 0;
        int n1;
        int n2;
        int n3;
        int n4;
        int n5;
        int n6;
        Scanner leer = new Scanner(System.in);
        int asierto1 = (int) (Math.random() * 40) + 1;
        int asierto2 = (int) (Math.random() * 40) + 1;
        int asierto3 = (int) (Math.random() * 40) + 1;
        int asierto4 = (int) (Math.random() * 40) + 1;
        int asierto5 = (int) (Math.random() * 40) + 1;
        int asierto6 = (int) (Math.random() * 40) + 1;
        System.out.println("ingrese los 6 numeros elegidos");
        System.out.println("numero 1");
        n1 = leer.nextInt();
        System.out.println("numero 2");
        n2 = leer.nextInt();
        System.out.println("numero 3");
        n3 = leer.nextInt();
        System.out.println("numero 4");
        n4 = leer.nextInt();
        System.out.println("numero 5");
        n5 = leer.nextInt();
        System.out.println("numero 6");
        n6 = leer.nextInt();
        if (asierto1 == n1) {
            System.out.println("el numero 1 es correcto");
            int pun1 = 1;
            System.out.println("resultado del numero 1) " + asierto1);
        } else {
            punt1 = 0;
        }
        System.out.println("resultado del numero 1) " + asierto1);
        if (asierto2 == n2) {
            System.out.println("el numero 2 es correcto");
            System.out.println("resultado del numero 2) " + asierto2);
            punt2 = 1;
        } else {
            punt2 = 0;
        }
        System.out.println("resultado del numero 2) " + asierto2);
        if (asierto3 == n3) {
            System.out.println("el numero 3 es correcto");
            System.out.println("resultado del numero 3) " + asierto3);
            punt3 = 1;
        } else {
            System.out.println("resultado del numero 3) " + asierto3);
        }
        punt3 = 0;
        if (asierto4 == n4) {
            System.out.println(" el numero 4 es crorrecto");
            System.out.println("resultado del numero 4} " + asierto4);
            punt4 = 1;
        } else {
            System.out.println("resultado del numero 4) " + asierto4);
        }
        punt4 = 0;
        if (asierto5 == n5) {
            System.out.println("el numero 5 es correcto ");
            System.out.println("resultado del numero 5)" + asierto5);
            punt5 = 1;
        } else {
            punt5 = 0;
        }
        System.out.println("resultado del numero 5) " + asierto5);
        if (asierto6 == n6) {
            System.out.println("el numero 6 es correcto");
            System.out.println("resultado del numero 6) " + asierto6);
            punt6 = 1;
        } else {
            punt6 = 0;
            System.out.println("resultado del numero 6) " + asierto6);
        }
        int puntaje_f = punt1 + punt2 + punt3 + punt4 + punt5 + punt6;
        System.out.println(" el puntaje obtenido es de " + puntaje_f);

// TODO code application logic here
    }
}
