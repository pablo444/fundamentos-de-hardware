/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg38;

import java.util.Scanner;

public class Ejercicio38 {

    public static void main(String[] args) {
        int sueldo = 0;
        int sueldoNuevo = 0;
        Scanner leer = new Scanner(System.in);
        System.out.print("          calculo de nuevo sueldo \n\n ingrse el suelso antiguo del trabajador hacendido: \n  $:");
        sueldo = leer.nextInt();
        sueldoNuevo = (sueldo / 100) * 110;
        System.out.println("el nuevo sueldo del trajador es " + sueldoNuevo);
        // TODO code application logic here
    }

}
