/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercco.pkg3.pkg11;

import java.util.Scanner;
import java.text.DecimalFormat;
public class Ejercco311 {

    public static void main(String[] args) {
      
        System.out.println("          calcular nota final\n\ningresar las notas sin numtoas ni comas \n   ej:  5.6 = 56 \n ");
        Scanner leer = new Scanner(System.in);
        int contador=0;
        double notaFinal=0;
        int notasT =0;
        int tarea =0;
        int num=0;
        int num2= 0;
        int num3=0;
        int notaOral=0;
       int  nPruevas=0;
        int[] promedios = new int[4];
       System.out.println("increse cantidad de pruebas parcieales (50%)");
        num3 = leer.nextInt();
           int[] notasParciales = new int[num3];
        for (int i = 0; i < num3; i++) {
            System.out.print("prueba n°"+(i+1)+" :");
         notasParciales[i]=leer.nextInt();
        nPruevas = nPruevas + notasParciales[i];
        }
        promedios[contador]=((nPruevas/num3)*50);
        contador++;
        System.out.println("\n increse cantidad de tallares (25%)");
        num = leer.nextInt();
        int[] notaTalleres = new int[num];   
        for (int i = 0; i < num; i++) {
            System.out.print("taller nota n°"+(i+1)+" :");
         notaTalleres[i]=leer.nextInt(); 
        notasT = notasT + notaTalleres[i];
        }
        promedios[contador]=((notasT/num)*25);
        contador++;
        System.out.println("\n increse cantidad de tareas (15%) ");
        num2 = leer.nextInt();
        int[] notaTareas = new int[num2];
        for (int i = 0; i < num2; i++) {
            System.out.print("tareas nota n°"+(i+1)+" :");
         notaTareas[i]=leer.nextInt();
        tarea = tarea + notaTalleres[i];
        }
        promedios[contador]=((tarea/num2)*15);
        contador++;
        System.out.println("\n ingrese las nota de la expocicion oral");
         notaOral=leer.nextInt();
         promedios[contador]=(notaOral*10);
         for (int i = 0; i < 4; i++) {
          notaFinal =(notaFinal +promedios[i])/100;
        }
        DecimalFormat df =new DecimalFormat("#.00");
         System.out.println("la nota final es "+df.format(notaFinal));
        // TODO code application logic here
    }

}
