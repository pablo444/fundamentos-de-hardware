package distancia.entre.dos.puntos;

import java.util.Scanner;

public class DistanciaEntreDosPuntos {

    static double distanciapp = 0;
    static Scanner leer = new Scanner(System.in);

    public static void main(String[] args) {

        punto p1 = new punto(0, 0);
        punto p2 = new punto(0, 0);

        ubicarPuntos(p1, p2);
        determinarDistancia(p1, p2);

    }

    public static void ubicarPuntos(punto p1, punto p2) {
        int y = 0;
        System.out.print("ingrese cordenadas para el punto 1 y el punto 2 \n punto 1.\n[x] = ");
        int x = leer.nextInt();
        p1.setCorX(x);
        System.out.print("[y] = ");
        y = leer.nextInt();
        p1.setCorY(y);
        System.out.print("\n punto 2.\n[x] = ");
        x = leer.nextInt();
        p2.setCorX(x);
        System.out.print("[y] = ");
        y = leer.nextInt();
        p2.setCorY(y);

        System.out.println("\nel punto 1 esta en : " + p1.getCorX() + "," + p1.getCorY());
        System.out.println("el punto 2 esta en : " + p2.getCorX() + "," + p2.getCorY() + "\n");
    }

    public static void determinarDistancia(punto p1, punto p2) {
        distanciapp = (double) Math.sqrt(((p1.getCorX() - p2.getCorX()) * (p1.getCorX() - p2.getCorX()))
                + ((p1.getCorY() - p2.getCorY()) * (p1.getCorY() - p2.getCorY())));

        System.out.println("la distancia entre el punto 1 y el punto 2 es: \n [distanci]=" + distanciapp);
    }
}
