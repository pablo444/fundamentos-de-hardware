/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3.pkg6.java;
import java.util.Scanner;
public class Ejercicio36Java {
   public static void main(String[] args) {
    Scanner lee = new Scanner(System.in) ;
      int[] puntos = new int[6];
      int[] puntos2 = new int[6];
      int dinero=0;
    String[]  producto = {" completos_italino", " completos a la chilena "," hamburguesas-queso "," churascos "," cerveza "," bebida "};
     int[] precios = {690,890,990,1100,700,500};
             System.out.println("              <calculo> \n");
        for (int i = 0; i <6; i++) {
                  System.out.print("cantidad de"+producto[i]+" vendido en el dia =");
             puntos[i]= lee.nextInt();
             puntos2[i] =puntos [i]*precios[i];
              }
       System.out.println("\n       en el dia se vendieron \n");
           for (int i = 0; i < 6; i++) {
           System.out.println( puntos[i]+" "+producto[i]+" en el dis y se gano con ello "+puntos2[i]);
           dinero=dinero+puntos2[i];
           }
           System.out.println(" \n    en total en el dia se gano "+dinero);
        // TODO code application logic here
    }
    
}
