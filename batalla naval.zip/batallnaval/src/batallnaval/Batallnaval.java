 package batallnaval;

import java.util.Scanner;

public class Batallnaval {

    static int barcosPersona = 0;
    static int barcos = 0;
    static int[] x = new int[10];
    static int[] y = new int[10];
    static Scanner leer = new Scanner(System.in);
    static boolean juego;
    static String[][] cordenadasDePc = new String[10][10];
    static String[][] cordenadasDePersona = new String[10][10];

    public static void main(String[] args) {
        System.out.println("  Start game (=_=)    \n(no introdusca comas)"
        );
        prepararTablas();
        tabla();
        PocicionarBarcosDeLaPersona();
        juego = true;
        do {
            tabla();
            disparos();
            if (barcos == 0) {
                juego = false;
            }
            if (barcosPersona == 0) {
                juego = false;
            }
        } while (juego);
        System.out.println("      end games (0_0) \n\n");
        if (barcos == 0) {
            System.out.println("   el ganador es PC");
        }
        if (barcosPersona == 0) {
            System.out.println("El ganador eres TU");
        }
    }

    public static void PocicionarBarcosDeLaPersona() {

        System.out.println("   (no repita las cohordanadas de los barcos)\ningresa las cordenadas [x,y] para ingresar los varcos");
        for (int i = 0; i < 10; i++) {
            do {
               do{
                System.out.print("barco n°" + (i + 1) + "\n[x]=");
                x[i] = leer.nextInt();
                System.out.print("[Y]=");
                y[i] = leer.nextInt();
                if (x[i] < 1 || x[i] > 10 || y[i] < 1 || y[i] > 10) {
                    System.out.println("sus cordenadas no exixten reingrese");
                }
                else if("°".equals( cordenadasDePersona[(x[i]) - 1][(y[i]) - 1])){
                    System.out.println("en estas coordenadas ya hay un berco \n            (reingrese) ");
                }
           
            }while (x[i] < 1 || x[i] > 10 || y[i] < 1 || y[i] > 10);
            }while("°".equals( cordenadasDePersona[(x[i]) - 1][(y[i]) - 1]));
            cordenadasDePersona[(x[i]) - 1][(y[i]) - 1] = "°";
            tabla();
        }

    }

    public static void prepararTablas() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                cordenadasDePc[i][j] = " ";
                cordenadasDePersona[i][j] = " ";
            }
        }
        for (int i = 0; i < 10; i++) {
            int aux2 = (int) (Math.random() * (10));
            int aux1 = (int) (Math.random() * (10));
            if (cordenadasDePc[aux1][aux2].endsWith("°")) {
                i--;
            } else {
                cordenadasDePc[aux1][aux2] = "°";
            }
        }
    }

    public static void tabla() {
        System.out.println(" player1 \n|1||2||3||4||5||6||7||8||9||10|_");
        barcosPersona = 0;
        for (int i = 0; i < 10; i++) {
            for (int k = 0; k < 10; k++) {
                System.out.print("[" + cordenadasDePersona[i][k] + "]");
                if (cordenadasDePersona[i][k].endsWith("°")) {
                    barcosPersona++;
                }
            }

            System.out.println("|" + (i + 1));
        }

        System.out.println("--------------- el jugador tiene " + barcosPersona + " barcos");
        System.out.println(" PC \n|1||2||3||4||5||6||7||8||9||10|_");
        barcos = 0;
        for (int i = 0; i < 10; i++) {
            for (int k = 0; k < 10; k++) {
                System.out.print("[" + cordenadasDePc[i][k] + "]");

                if (cordenadasDePc[i][k].endsWith("°")) {
                    barcos++;
                }
            }
            System.out.println("|" + (i + 1));
        }
        System.out.println("--------------- el pc tiene " + barcos + " barcos");
    }

    public static void disparos() {
        int tiroy = 0;
        int tirox = 0;
        int tiropcX = 0;
        int tiropcY = 0;
        do {
            System.out.print("ingrese cordenadas de su disparo [x,y] \n[x]=");
            tirox = leer.nextInt();
            System.out.print("[y]=");
            tiroy = leer.nextInt();
            if (tirox < 1 || tirox > 10 || tiroy < 1 || tiroy > 10) {
                System.out.println("sus cordenadas no exixten reingrese");
            }
        } while (tirox < 1 || tirox > 10 || tiroy < 1 || tiroy > 10);
        if ("°".equals(cordenadasDePc[tiroy - 1][tirox - 1])) {
            cordenadasDePc[tiroy - 1][tirox - 1] = "#";
        }
        if (" ".equals(cordenadasDePc[tiroy - 1][tirox - 1])) {
            cordenadasDePc[tiroy - 1][tirox - 1] = "*";
        }

        tiropcX = (int) (Math.random() * (10));
        tiropcY = (int) (Math.random() * (10));
        if ("°".equals(cordenadasDePersona[tiropcX][tiropcY])) {
            cordenadasDePersona[tiropcY][tiropcX] = "#";
        } else if (" ".equals(cordenadasDePersona[tiropcX][tiropcY])) {
            cordenadasDePersona[tiropcY][tiropcX] = "*";
        }
    }

    // TODO code application logic here
}
