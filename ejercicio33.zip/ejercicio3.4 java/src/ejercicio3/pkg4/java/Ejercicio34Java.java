/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3.pkg4.java;
import java.util.Scanner;

public class Ejercicio34Java {
    public static void main(String[] args) {
      Scanner lee = new Scanner(System.in);
        System.out.println("ingrese numero 1");
       int num1 = lee.nextInt();
        System.out.println("ingrese numero 2");
        int num2 = lee.nextInt();
        System.out.println("ingrese numero 3");
        int num3 = lee.nextInt();
        
        double promedio = (num1+num2+num3)/3 ;
        int suma = num1+num2+num3;
        int doble_de_1 =num1*2;
        int triple_del_2 = num2*3;
        int trecero_al_cuadrado = num3*num3;
        System.out.println("el promedio de los numreso es : "+promedio);
        System.out.println("la suma de los numeros es : "+suma);
        System.out.println("el doble del primer numero es : "+doble_de_1);
        System.out.println("el triple del segundo numero es : "+triple_del_2);
        System.out.println("el tercer numero al cuadrado es "+trecero_al_cuadrado);
        
        
        // TODO code application logic here
    }
    
}
