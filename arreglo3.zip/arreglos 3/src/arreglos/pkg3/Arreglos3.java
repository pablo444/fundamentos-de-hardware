/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglos.pkg3;
import java.util.Scanner;
public class Arreglos3 {

    public static void main(String[] args) {
         Scanner lee = new Scanner(System.in);
        int nuc;
        int i = 0;
            System.out.println("ingrese el numero de celdas ( recuerde del 1 al 100)");
            nuc = lee.nextInt();
            if (nuc < 0 || nuc > 100) {
                System.out.println("el numero es invalido repita ");
            }
           int [] numero = new int[nuc];
           for (int x = 0 ;  x < numero.length/2 ; x++ ){
               numero[x] = (int) (Math.random()*100)+1;
               numero [numero.length - 1- x ] = numero[x];}
        
           for (int x =0; i < numero.length ;i++){
               System.out.println("el numero de la celda n°"+(i+1)+" "+numero[i]+" "); }
            
         // TODO code application logic here
    }
    
} 
