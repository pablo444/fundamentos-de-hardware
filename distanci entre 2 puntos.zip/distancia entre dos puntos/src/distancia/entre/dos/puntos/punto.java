
package distancia.entre.dos.puntos;

public class punto {
private int corX;
private int corY;

    public punto(int corX, int corY) {
        this.corX = corX;
        this.corY = corY;
    }

    public int getCorX() {
        return corX;
    }

    public void setCorX(int corX) {
        this.corX = corX;
    }

    public int getCorY() {
        return corY;
    }

    public void setCorY(int corY) {
        this.corY = corY;
    }

  
}
