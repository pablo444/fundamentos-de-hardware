/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3.pkg1java;
import java.util.Scanner;
public class Ejercicio31java {

public static void main(String[] args) { 
   int  Radio ;
   int  Altura ;
           
    Scanner leer = new Scanner(System.in);
    System.out.println("ingrese radio del cilindro (r)");
    Radio = leer.nextInt();
    System.out.println("ingrese la altura del cilindro (h)");
    Altura = leer.nextInt();
     double Volumen = Radio*Radio*3.14*Altura;
     double Area    =((Radio*3.14*2)*Altura )+ 2*(Radio*Radio*3.14) ;
     System.out.println("el area de cilindro es "+Area);
     System.out.println("el volumen del cilindro es "+Volumen);
     
    
            
        
        // TODO code application logic here
    }
    
}
