package loto.tareas;

import java.util.Scanner;

public class LotoTareas {
    
    static int opcion =0;
    static int num = 0;
    static String[] premioTipo1 = {"$1000000 USD", "Crucero", "Vuelta al mundo"};
    static String[] premioTipo2 = {"Televisor 55 UHD", "Sistema de Sonido HIFI", "Entradas VIP para concierto",
        "Camara fotografica profesional"};
    static String[] premioTipo3 = {"Nuevo Carton", "Suscripción a Spotify por un mes"};
    static int[][] []carton = new int[num][3][5];
    static int[][] cartonJuego = new int[3][5];
    static Scanner leer = new Scanner(System.in);
    static int juego=0;
    
    public static void main(String[] args) {
        prepararCarton();
       do{
      juego++;
       do{
  
           System.out.print("\n    juego n°"+juego);
        System.out.println("\n1)ingresar numero de cartones \n2)llenar cartones \n3)jugar el sorteo "
                + "\n4)terminar de juegar \n5)bolver a jugar");
         opcion = leer.nextInt();
      
         if(opcion==1){
         eleccionDeNumeroDeCartones();}
       if (opcion==2){
       llenarEImprimirCarton();}
       if(opcion ==3) {
       jugar();}
      }while(opcion!=4 && opcion!=5);
       }while(opcion!=4);
              
    }
    
     public static void prepararCarton() {
    for (int i = 0; i < num; i++) {
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 5; k++) {
                    carton[i][j][k] =0;
                }
            }
        }}
    
    public static void eleccionDeNumeroDeCartones() {
        System.out.println("elija numero de cartones que desea jugar ");
        num = leer.nextInt();
          carton = new int[num][3][5];
    }
    
    public static void llenarEImprimirCarton() {
    for (int i = 0; i < num; i++) {
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 5; k++) {
                   int aux=  (int) (Math.random()*49)+1;
                    carton[i][j][k] =aux;
                }
            }
        }
         for (int i = 0; i < num; i++) {
             System.out.println("carton n°"+(i+1));
             for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 5; k++) {
                    System.out.print("[  "+carton[i][j][k]+" ]");
                }
                System.out.println("");
            }
        }

    }
    
  public static void jugar(){
      for (int i = 0; i < 3; i++) {
          for (int j = 0; j < 5; j++) {
              cartonJuego[i][j]=(int)(Math.random()*49)+1;
          }
      }
      System.out.println("");
      System.out.println("sorteo :)");
      for (int i = 0; i < 3; i++) {
          for (int j = 0; j < 5; j++) {
              System.out.print("[ "+cartonJuego[i][j]+" ]");
          }
          System.out.println("");
      }
  
          for (int i = 0; i < num; i++) {
              System.out.println("");
              int contador=0;
              for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 5; k++) {
                 if(carton[i][j][k]==cartonJuego[j][k]){
                  contador++   ;
                 }
                }
            }
              System.out.println("EL carton n°"+(i+1 )+" tiene ["+contador +"]  aciertos");
              if(contador > 0 &&  contador <= 3){
                  System.out.println("sigua participando  0_0");
              }
              else if(contador>3 && contador >=6){
                  System.out.println("felicitaciones has ganado");
                  for (int j = 0; j < 2; j++) {
                  System.out.println(premioTipo3[i]);}
              }
             else if(contador>6 && contador >=14){
                  System.out.println("felicitaciones has ganado");
                  for (int j = 0; j < 4; j++) {
                  System.out.println(premioTipo2[i]);}
              }
            else if(contador==15){
                  System.out.println("felicitaciones has ganado otra oportunidad de jugar");
                  for (int j = 0; j < 3; j++) {
                  System.out.println(premioTipo1[i]);}
              }

}}
// TODO code application logic here
}
