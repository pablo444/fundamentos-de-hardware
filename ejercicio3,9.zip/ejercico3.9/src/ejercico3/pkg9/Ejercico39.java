/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercico3.pkg9;

import java.util.Scanner;

public class Ejercico39 {
static double suma=0;
    public static void main(String[] args) {
       
        Scanner leer=new Scanner(System.in);
        double[] tiempos= new double[6];
        String[] dias ={" lunes "," martes "," miercole "," jueves "," viernes "," sabado "};
        System.out.println("ingrese el tiempo en minutos recorrido por el deportista");
        for (int i = 0; i < 6; i++) {
            System.out.print(" en el dia "+dias[i]+" = ");
            tiempos[i]=leer.nextInt();
            suma= suma+tiempos[i];
        }
        System.out.println(" ");
        for (int i = 0; i < 6; i++) {
            System.out.println("el deportista tardo "+tiempos[i]+" minutos en recorrer la rruta el dia"+dias[i]);
        }
        suma = suma/6;
        System.out.println("\n el tiempo promedio que tarda el deportista en racorrer la ruta en la semana es "+suma+" minutos");
        
        // TODO code application logic here
    }
    
}
