/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.de.arreglo;

import java.util.Scanner;

public class EjercicioDeArreglo {

    public static void main(String[] args) {
        Scanner lee = new Scanner(System.in);
        int i;
        int nuc = 1;
        int munero = 0;
        int numPares = 0;
        int numImpar = 0;
        int primos = 0;
        int numBuscar = 0;
        do {
            System.out.println("ingrese el numero de celdas ( recuerde del 1 al 100)");
            nuc = lee.nextInt();
            if (nuc < 0 || nuc > 100) {
                System.out.println("el numero es invalido repita ");
            }
        } while (nuc < 0 || nuc > 100);
        int numero[] = new int[nuc];
        for (i = 0; i < nuc; i++) {
            numero[i] = (int) (Math.random() * 100) + 1;
            System.out.println("el numero la celda n°" + (i+1) + " es: " + numero[i]);
            if (numero[i] % 2 == 0) {
                numPares = numPares + 1;
            } else {
                numImpar = numImpar + 1;
            }
        }
        System.out.println("   ");
        System.out.println("la cantidad de numeros pares en las celdas son: " + numPares);
        System.out.println("la cantidad de numeros impates en las celdas es: " + numImpar);
        System.out.println("    ");
        System.out.println("que numero desea buscar? :");
        numBuscar = lee.nextInt();
        int numrepetido = 0;
        for (i = 0; i < nuc; i++) {
            if (numero[i] == numBuscar) {
                numrepetido++;
            }
        }
        System.out.println("el numero " + numBuscar + " se encontro " + numrepetido + " veces en el arreglo");

        // TODO code application logic here
    }
}
