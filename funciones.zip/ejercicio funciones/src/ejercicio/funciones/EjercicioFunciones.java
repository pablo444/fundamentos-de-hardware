
/* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. */
package ejercicio.funciones;

import java.util.Scanner;

public class EjercicioFunciones {

    public static void main(String[] args) {
        int i = 0;
        int funcion = 0;
        do {
            ++i;
            int numeros[] = new int[5];
            Scanner leer = new Scanner(System.in);
           do {
            System.out.println("      MENU " + i + ".\n1)ingresar arreglo\n2)muestra arreglo\n3)muestra mayor");
            System.out.println("4)muestra menor\n5)mostrar promedio de los numeros\n6)ordenar\n7)salir");
            
                System.out.println("ingrese su opcion");
                funcion = leer.nextInt();
                if (funcion == 1) {
                    ingresar(numeros);
                }
                if (funcion == 2) {
                    mostrarNumeros(numeros);
                }
                if (funcion == 3) {
                    mostrarNumeroMayor(numeros);
                }
                if (funcion == 4) {
                    mostrarNumeroMenor(numeros);
                }
                if (funcion == 5) {
                    calcularPromedio(numeros);
                }
                if (funcion == 6) {
                 numeros =  ordenar(numeros);   
                }
                if (funcion == 7) {
                    System.exit(0);
                }
                System.out.println("===============================================");
            } while (funcion < 7);
        } while (funcion == 8 || funcion > 7);
    }
     
    public static void ingresar(int[] numero) {
        System.out.println("ingrsar numeros del arreglo de 5 celdas");
        Scanner lee = new Scanner(System.in);
        for (int i = 0; i < 5; ++i) {
            System.out.println("ingrese numero un para la celda " + (i + 1) + " :");
            numero[i] = lee.nextInt();
        }
    }

    public static void mostrarNumeros(int[] numero) {
        int numer = 0;
        System.out.println("estos son los numeros que ingresaste");

        for (int i = 0; i < 5; ++i) {
            System.out.println(-numero[i]);
        }
    }

    public static void mostrarNumeroMayor(int[] numero) {
        int mayor = 0;
        for (int i = 0; i < 5; ++i) {
            if (numero[i] > mayor) {
                mayor = numero[i];
            }
        }
        System.out.println("este es el numero mas grande en el arreglo es :" + mayor);
    }

    public static void mostrarNumeroMenor(int[] numero) {
        int menor = 100000;
        for (int i = 0; i < 5; ++i) {
            if (numero[i] < menor) {
                menor = numero[i];
            }
        }
        System.out.println("este es el numero mas pequeño  en el arreglo es :" + menor);
    }

    public static void calcularPromedio(int[] numero) {
        int promedio = 0;
        for (int i = 0; i < 5; ++i) {
            promedio = promedio + numero[i];
        }
        promedio = promedio / 5;
        System.out.println("el promedio de los nummeros es :" + promedio);
    }

    public static int[] ordenar(int[] numero) {
    
        for (int i = 0; i < numero.length; i++) {
            for ( int j = 0; j < numero.length - 1; j++) {
                if (numero[j] > numero[j + 1]) {
                    int aux = numero[j];
                    numero[j] = numero[j + 1];
                    numero[j + 1] = aux;
                    
                }
            }
           System.out.println(- numero[i]); 
        }  
        return numero;
        
    }

// TODO code application logic here

}