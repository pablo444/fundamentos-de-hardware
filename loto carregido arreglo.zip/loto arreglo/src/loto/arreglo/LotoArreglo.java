
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loto.arreglo;

import java.util.Scanner;

public class LotoArreglo {
    

    public static void main(String[] args) {
        Scanner lee = new Scanner(System.in);
        int i = 0;
        
        int asiertos = 0;
        int numero[] = new int[15];
        int numeroAliatorio[] = new int[15];

        System.out.println("ingese los numeros que desea comprar : \n recuerde entre 41 y 1");
        for (i = 0; i < 15; ++i) {
            do {
                System.out.print("n°"+(i+1)+" =");
                numero[i] = lee.nextInt();
                if (numero[i] > 41 || numero[i] < 1) {
                    System.out.println("numero inbalido");
                }
            } while (numero[i] < 1 || numero[i] > 41);
        }
        System.out.println("los numero sorteo son ");
        for (i = 0; i < 15; ++i) {
         
                numeroAliatorio[i] = (int) (Math.random() * 40) + 1;
                if (numero[i] == numeroAliatorio[i]) {
                    asiertos = asiertos + 1;
                }}
        for ( i = 0; i < 15; ++i) {
            System.out.println( numeroAliatorio[i]);
        }
        System.out.println(" los numeros asertados " + asiertos + " ");
        // TODO code application logic here

    }}
