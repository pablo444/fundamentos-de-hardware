/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrailis.ejercicio;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrailisEjercicio {
    static int aux =0;
    static int buscado = 0;
    static int insertar = 0;
    static int contador = 0;
    static Scanner leer = new Scanner(System.in);
    static ArrayList<Integer> indise = new ArrayList();
    static ArrayList<Integer> numeros = new ArrayList(15);
    static ArrayList<Integer> numerosRandom = new ArrayList(15);
    static int opcion=0;
    public static void main(String[] args) {
     do{
      System.out.print("    Menu\n1)ingresar numeros al arreglo\n2)tirar nuemros en erreglo ramdon\n3)imprimir arreglos y buscar numero"
             + "\n4)borrar \n5)salir \n \n");
       for(int i=0;i<15;++i){
      int p=0;
      numeros.add(p);
      numerosRandom.add(p) ;}
      opcion= leer.nextInt();
      if(opcion==1){
         ingresarNumeros(); 
      }
      else if(opcion==2){
         trirarRamdonSinRepetidos();
     }
      else if(opcion==3){
          imprimirYBuscar();
      }
      else if(opcion==4){
          borrarAreglos();
      }
     } while(opcion !=5 || opcion>5);  
    }
        public static void ingresarNumeros(){
        System.out.println("ingrese los 15 numeros");
        for (int i = 0; i < 15; i++) {
            System.out.print("n°" + (i + 1) + " =");
            insertar = leer.nextInt();
            numeros.add(insertar);
        }}
       public static void trirarRamdonSinRepetidos(){
        for (int i = 0; i < 15; i++) {
            int mero = (int) (Math.random() * 100) + 1;
            numerosRandom.add(mero);
            for (int j = 0; j < i; j++) {
                if (numerosRandom.get(i) == numerosRandom.get(j)) {
                    numerosRandom.remove(j);
                    --i;
                }
            }
            System.out.println("n°"+i+" ="+numerosRandom.get(i));
        }}
        public static  void imprimirYBuscar(){
        for (int i = 0; i < 15; ++i) {
            System.out.println("nuemro n°" + (i + 1) + " = " + numeros.get(i) + "         nuemro aliatoros n°" + (i + 1) + " = " + numerosRandom.get(i));
        }
        System.out.println("que numero desea buscar en los arreglos");
        buscado = leer.nextInt();
        for (int i = 0; i < 15; i++) {
            if (numeros.get(i) == buscado) {
                 aux = i;
                indise.add(aux);
                contador = contador + 1;
            }
        }
        for (int i = 0; i < 15; i++) {
            if (numerosRandom.get(i) == buscado) {
                aux = i;
                indise.add(aux);
                contador = contador + 1;
            }
        }
        if (contador > 0) {
            System.out.println("el numero fue encontrado " + contador + " en el arreglo y sus indises son ");
            for (int i = 0; i < contador; i++) {
                System.out.print((indise.get(i) + 1) + " - ");
            }
        } else {
            System.out.println(" el numero no se encontro");
        }}
       public static void borrarAreglos(){
        numeros.clear();
        numerosRandom.clear();}

        // TODO code application logic here
    

}